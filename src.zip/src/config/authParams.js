
module.exports = {
    clientId: 'QnnSqpADPNZUTD4dPbfYE9PWodk17g~pBKDH60VD',
    ClientSecret: '88o~YKjqpTk_YzQ1d8DJlYc6tfFwMoDeySHwPNBc_8DuZc8CI4c7BixSd6UfqdGelL2fPZRZluqp9B3f9y2aJyd0YnuCgTf5cU3A',
    spikeHost: 'https://51.144.178.121' ,
    spikePort: '1337',
    tokenPath: '/oauth2/token',
    scope: ['read', 'write'],
    audience: 'kartoffel',
    publicKeyPath: '/.well-known/publicKey.pem'
}

// 51.144.178.121
// : 1337 authServer
// : 3000 spikeServer
// : 4200 client