const migration = require('./migration');

migration()
