module.exports = {
    rootHierarchy: ['armagadon', 'bladerunners', 'interstellar', 'odyssey'],
    miriMail: 'turtleS.com',
    idPrefixes: ['e', 'e', 'e', 'e', 'e', 'e', 'e', 'e',
                 'g', 'g',
                 'l',
                 'j',
                 'i',
                 'm', 'm', 'm'],
}