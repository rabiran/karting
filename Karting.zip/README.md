# karting
Data analyze app, importing and synchronized data from api`s


## install
/sudo apt-get -f install 


sudo apt-get install build-essential

## docker-compose
if you want enable auth in kartoffel, change config in "./docker-compose-config/kartoffel/kartoffel.env"
docker-compose up --build -d
