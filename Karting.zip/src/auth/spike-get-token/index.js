const { getTokenCreator } = require("./utils/getToken");

module.exports = getTokenCreator;