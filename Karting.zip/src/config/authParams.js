module.exports = {
    clientId: 'CYrZ4GT3x1gjyyM2kcZDtDyp1HZYNcM~B9XlXZ3I',
    ClientSecret: '9hwbLnqXNtdrr6eRHirMRMwmsq3KqMyX528jKJjpWNSpvtDMiT1kofHJY60kjcCD59t_LUXRnlCC8xRiVD1~BhoB7TrGohXouvm1',
    spikeHost: 'https://51.144.178.121',
    spikePort: '1337',
    tokenPath: '/oauth2/token',
    scope: ['read', 'write'],
    audience: 'kartoffel',
    publicKeyPath: '/.well-known/publicKey.pem',
}