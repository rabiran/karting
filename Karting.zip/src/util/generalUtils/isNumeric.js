module.exports = (value) => {
    return !isNaN(parseInt(value.toString()));
}